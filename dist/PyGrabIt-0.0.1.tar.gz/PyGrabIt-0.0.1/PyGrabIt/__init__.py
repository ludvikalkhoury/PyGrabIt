from .Library import GraphGrabberApp

__version__ = GraphGrabberApp.Version
